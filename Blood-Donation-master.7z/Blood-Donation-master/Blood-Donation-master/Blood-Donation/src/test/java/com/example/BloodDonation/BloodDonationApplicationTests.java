package com.example.BloodDonation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BloodDonationApplicationTests {

	@Test
	void contextLoads() {
	}

}

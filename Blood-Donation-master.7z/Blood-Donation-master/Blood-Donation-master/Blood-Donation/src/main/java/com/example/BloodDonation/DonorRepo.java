package com.example.BloodDonation;

import org.springframework.data.repository.CrudRepository;

public interface DonorRepo extends CrudRepository<Donor,String>
{

}

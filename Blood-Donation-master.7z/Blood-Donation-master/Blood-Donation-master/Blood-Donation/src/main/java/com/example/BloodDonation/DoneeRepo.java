package com.example.BloodDonation;

import org.springframework.data.repository.CrudRepository;

public interface DoneeRepo extends CrudRepository<Donee,String>
{

}

package com.example.BloodDonation;

import org.springframework.data.repository.CrudRepository;

public interface LoginRepo extends CrudRepository<Login,String>
{

}
